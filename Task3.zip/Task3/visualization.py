# Task 3: Data Visualization
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
# Personal Info
AUTHOR = "Faizan Ahmad"
USERNAME = "faizan4232"
DATA_FILE = "Titanic-Dataset.csv"

# Output Folder
SAVE_DIR = Path("faizan_visuals")
SAVE_DIR.mkdir(exist_ok=True)

# Theme
sns.set_theme(style="whitegrid")
gradient_blue = sns.color_palette("blend:#0D47A1,#42A5F5,#BBDEFB", 8)
# Load Data
try:
    df = pd.read_csv(DATA_FILE)
    print(f"Dataset loaded successfully for {AUTHOR}")
except FileNotFoundError:
    print("Titanic-Dataset.csv not found.")
    exit()
# Helper Function
def save_and_show(filename):
    plt.tight_layout()
    plt.savefig(SAVE_DIR / filename, dpi=300)
    plt.show()
    plt.close()
# 1. Survival Count
plt.figure(figsize=(8,5))
ax = sns.countplot(
    data=df,
    x="Survived",
    hue="Survived",
    palette=gradient_blue,
    legend=False
)
plt.title("Passenger Survival Count", fontsize=14, weight="bold")
plt.xticks([0,1], ["Not Survived", "Survived"])
for p in ax.patches:
    ax.annotate(int(p.get_height()),
                (p.get_x()+p.get_width()/2, p.get_height()),
                ha="center", va="bottom")
save_and_show("1_survival_count.png")
# 2. Passenger Class Count
plt.figure(figsize=(8,5))
ax = sns.countplot(
    data=df,
    x="Pclass",
    hue="Pclass",
    palette=gradient_blue,
    legend=False
)
plt.title("Passenger Class Distribution", fontsize=14, weight="bold")
for p in ax.patches:
    ax.annotate(int(p.get_height()),
                (p.get_x()+p.get_width()/2, p.get_height()),
                ha="center", va="bottom")
save_and_show("2_class_distribution.png")

# 3. Survival by Gender
plt.figure(figsize=(8,5))
sns.countplot(
    data=df,
    x="Sex",
    hue="Survived",
    palette=gradient_blue
)
plt.title("Survival Based on Gender", fontsize=14, weight="bold")
save_and_show("3_survival_gender.png")
# 4. Age Distribution
plt.figure(figsize=(9,5))
sns.histplot(
    df["Age"].dropna(),
    bins=25,
    kde=True,
    color=gradient_blue[4],
    edgecolor="black"
)
plt.title("Age Distribution", fontsize=14, weight="bold")
plt.xlabel("Age")
plt.ylabel("Passengers")
save_and_show("4_age_distribution.png")
# 5. Fare Distribution
plt.figure(figsize=(9,5))
sns.histplot(
    df["Fare"],
    bins=30,
    kde=True,
    color=gradient_blue[6],
    edgecolor="black"
)
plt.title("Fare Distribution", fontsize=14, weight="bold")
plt.xlabel("Fare")
plt.ylabel("Passengers")
save_and_show("5_fare_distribution.png")

# 6. Fare by Class (Boxplot)
plt.figure(figsize=(8,5))
sns.boxplot(
    data=df,
    x="Pclass",
    y="Fare",
    hue="Pclass",
    palette=gradient_blue,
    legend=False
)
plt.title("Fare by Passenger Class", fontsize=14, weight="bold")
save_and_show("6_fare_by_class.png")
# Final Message
print("\nAll charts displayed and saved successfully.")
print(f"Saved in folder: {SAVE_DIR}")
print(f"Prepared by: {AUTHOR} ({USERNAME})")