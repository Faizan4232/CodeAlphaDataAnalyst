# Task 4: Sentiment Analysis
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from textblob import TextBlob
from pathlib import Path
USER = "Faizan Ahmad"
USERNAME = "faizan4232"
BASE = Path(__file__).parent
INPUT_FILE = BASE / "faizan_sentiment_results.csv"
RESULT_FILE = BASE / "faizan_sentiment_results.csv"
CHART_FILE = BASE / "faizan_sentiment_chart.png"
sns.set_theme(style="whitegrid")
colors = ["#0D47A1", "#42A5F5", "#BBDEFB"]
def detect_sentiment(text):
    score = TextBlob(str(text)).sentiment.polarity
    if score > 0.1:
        return "Positive"
    elif score < -0.1:
        return "Negative"
    return "Neutral"
def load_file():
    # Try automatic separators
    for sep in [",", ";", "\t", "|"]:
        try:
            df = pd.read_csv(INPUT_FILE, sep=sep)
            if df.shape[1] >= 2:
                return df
        except:
            pass
    # One-column fallback
    df = pd.read_csv(INPUT_FILE, header=None, names=["raw"])
    split_data = df["raw"].str.split(",", n=1, expand=True)

    if split_data.shape[1] == 2:
        split_data.columns = ["Review", "Sentiment"]
        return split_data
    return None
def main():
    df = load_file()

    if df is None:
        print("Could not read file correctly.")
        return
    print(f"\nDataset loaded successfully for {USER}")

    df.columns = df.columns.str.strip()
    df = df.iloc[:, :2]
    df.columns = ["Review", "Sentiment"]

    # Clean labels
    df["Sentiment"] = df["Sentiment"].astype(str).str.strip().str.title()
    # Predict
    df["Predicted_Sentiment"] = df["Review"].apply(detect_sentiment)

    print("\n========== SAMPLE DATA ==========\n")
    print(df.head(10))

    # Save file
    df.to_csv(RESULT_FILE, index=False)

    # Chart
    counts = df["Predicted_Sentiment"].value_counts()

    plt.figure(figsize=(8,5))
    ax = counts.plot(kind="bar", color=colors, edgecolor="black")

    plt.title("Sentiment Analysis Summary", fontsize=14, weight="bold")
    plt.xlabel("Sentiment")
    plt.ylabel("Total Reviews")

    for p in ax.patches:
        ax.annotate(
            int(p.get_height()),
            (p.get_x()+p.get_width()/2, p.get_height()),
            ha="center",
            va="bottom"
        )
    plt.tight_layout()
    plt.savefig(CHART_FILE, dpi=300)
    plt.show()
    plt.close()
    print("\n========== TASK COMPLETED ==========")
    print("Created Files:")
    print("-", RESULT_FILE.name)
    print("-", CHART_FILE.name)
    print(f"\nPrepared by {USER} ({USERNAME})")
if __name__ == "__main__":
    main()